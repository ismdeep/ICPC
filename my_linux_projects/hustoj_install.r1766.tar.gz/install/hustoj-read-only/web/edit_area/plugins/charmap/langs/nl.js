editArea.add_lang("nl",{
charmap_but: "Visueel toetsenbord",
charmap_title: "Visueel toetsenbord",
charmap_choose_block: "Kies een taal blok",
charmap_insert:"Voeg dit symbool in"
});
