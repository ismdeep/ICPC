<?php 
	require("template/".$OJ_TEMPLATE."/oj-footer.php");
	?>
