<?php
  header("Location:../");
?>
