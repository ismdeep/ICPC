<?php
if ($_SESSION['getkey']!=$_GET['getkey'])
	exit(1);
?>
