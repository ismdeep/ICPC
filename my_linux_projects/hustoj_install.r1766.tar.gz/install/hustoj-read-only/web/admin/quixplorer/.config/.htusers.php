<?php $GLOBALS["users"]=array(
	array("admin","noboylogin",".","http://localhost",1,"",7,1),
); ?>
