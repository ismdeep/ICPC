/* [code] <p>
[code] [blank] * Project Name : [code] [project_name] [code] <p>
[code] [blank] * [code] <p>
[code] [blank] * File    Name : [code] [file_name] [code] <p>
[code] [blank] * [code] <p>
[code] [blank] * Author  Name : [code] [author_name] [code] <p>
[code] [blank] * [code] <p>
[code] [blank] * Date &  Time : [code] [date_and_time] [code] <p>
[code] [blank] * [code] <p>
[code] [blank] * */ [code] <p>


#include <set> [code] <p>
#include <map> [code] <p>
#include <list> [code] <p>
#include <cmath> [code] <p>
#include <ctime> [code] <p>
#include <deque> [code] <p>
#include <queue> [code] <p>
#include <stack> [code] <p>
#include <cctype> [code] <p>
#include <cstdio> [code] <p>
#include <string> [code] <p>
#include <vector> [code] <p>
#include <cassert> [code] <p>
#include <cstdlib> [code] <p>
#include <cstring> [code] <p>
#include <sstream> [code] <p>
#include <iostream> [code] <p>
#include <algorithm> [code] <p>
[code] <p>
using namespace std; [code] <p>
[code] <p>
#define _ISM_DEBUG_ [code] <p>
[code] <p>
int main () [code] <p>
{ [code] <p>
[code] [tab] return 0; [code] <p>
} [code] <p>
// end [code] <p>
// [code] [author_name] [code] <p>
// [code] [lab_name] [code] <p>
// [code] <p>
[code] <p>

