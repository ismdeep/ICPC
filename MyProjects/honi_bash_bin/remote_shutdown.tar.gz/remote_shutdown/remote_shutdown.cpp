#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;


#ifndef SCAN_TIME_SLEEP
#define SCAN_TIME_SLEEP 60
#endif

string paste_id = "User:Xhoonacker";

int main ()
{
	bool do_shutdown = false;
	while (!do_shutdown)
	{
		string rm_instruc = "rm " + paste_id;
		system (&rm_instruc[0]);
		string wget_instruc = "wget -q http://zh.wikipedia.org/wiki/" + paste_id;
		system (&wget_instruc[0]);
		ifstream infile (&paste_id[0], ios::in);
		string str;
		while (infile >> str)
		{
			if ("ismdeep-shutdown" == str)
			{
				system ("poweroff");
			}
		}
		infile.close ();
		sleep (SCAN_TIME_SLEEP);
	}
	return 0;
}

// end 
// iCoding
//

