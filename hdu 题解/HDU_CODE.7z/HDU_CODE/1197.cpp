//3.14  20min Accepted 1197 0MS 228K 
#include<iostream>
using namespace std;
int check16(int n,int sum)
{
	int res=0,i=0,t[5]={0};
	while(n)
	{
		t[i++]=n%16;
		n=n/16;
	}
	for(i=0;i<5;i++)
		res += t[i];
	if(sum == res )		return 1;
	return 0;
}
int check12(int n,int sum)
{
	int res=0,i=0,t[5]={0};
	while(n)
	{
		t[i++]=n%12;
		n=n/12;
	}
	for(i=0;i<5;i++)
		res += t[i];
	if(sum == res )		return 1;
	return 0;
}
int main()
{
	int n,m,i,j,k,sum=0;
	for(i=2992;i<10000;i++)
	{
		sum=0;
		sum += i%10;
		sum += i%100/10;
		sum += i%1000/100;
		sum += i%10000/1000;
		if(check16(i,sum)==1&&check12(i,sum)==1)
			printf("%d\n",i);
	}
}

