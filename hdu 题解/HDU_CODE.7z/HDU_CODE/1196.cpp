//��ٷ�
#include<stdio.h>
int main()
{
	int n;
	while(scanf("%d",&n)&&n)
	{
		int k,a[10],i=9,m,j;
		for(k=0;k<10;k++)
			a[k]=0;
		while(n)
		{
			a[i]=n%2;
			n /= 2;
			i--;
		}
		for(j=9;j>0;j--)
		{
			if(1==a[j])
			{
				if(j==9)
					printf("1\n");
				if(j==8)
					printf("2\n");
				if(j==7)
					printf("4\n");
				if(j==6)
					printf("8\n");
				if(j==5)
					printf("16\n");
				if(j==4)
					printf("32\n");
				if(j==3)
					printf("64\n");
				if(j==2)
					printf("128\n");
				break;
			}
		}
	}
}