/*
1089 A+B for Input-Output Practice (I)
Time Limit : 1000 ms  Memory Limit : 32768 K  Output Limit : 5120 K  
VC
*/
#include <stdio.h>
int main()
{
	int num1,num2;
	while(scanf("%d %d",&num1,&num2)==2)
	{
		printf("%d\n",num1+num2);
	}
	return 0;
}
