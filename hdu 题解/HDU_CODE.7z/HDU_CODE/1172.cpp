//???
#include<iostream>
using namespace std;
int judge(int or,int a,int b,int c)
{
	int orz[4],az[4],time=0;
	for(i=0;i<4;i++)
	{
		if(arz[i]==az[i])
			time++;
	}
	for()
	if(time == c)
}
int main()
{
	int n,m,i,j,k,t[100][4],temp,a,b,c;
	while(scanf("%d",&n)&& n)
	{
		for(i=0;i<n;i++)
		{
			scanf("%d%d%d",&a,&b,&c);

		}
		for(i=0;i<=9999;i++)
		{
			if()
			{}
			else
				break;
		}

	}
}
