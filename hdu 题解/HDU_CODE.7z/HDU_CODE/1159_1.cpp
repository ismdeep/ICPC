//3.11 10min Accepted 1159 62MS 4188K 589 B 
#include<iostream>
#include<string>
using namespace std;
char  a[1002],b[1002];
int tab[1002][1002];
int main()
{
	int n,m,i,k,j,alen,blen;
	
	while(scanf("%s %s",a,b)!=EOF)
	{
		memset(tab,0,sizeof(tab));
		alen  = strlen(a);
		blen = strlen(b);
		for(i=0;i<=alen ;i++)
			tab[i][0] = 0;
		for(i=0;i<=blen;i++)
			tab[0][i]=0;
		for(i=0;i<alen;i++)
		{
			for(j=0;j<blen;j++)
			{
				if(a[i]==b[j])
					tab[i+1][j+1]= tab[i][j]+1;
				else tab[i+1][j+1] = tab[i][j+1]>tab[i+1][j]?tab[i][j+1]:tab[i+1][j];
			}	
		}
		printf("%d\n",tab[alen][blen]);
	}
}

