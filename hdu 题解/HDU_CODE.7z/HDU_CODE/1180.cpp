//Wrong Answer 1180 0MS 296K ������
#include<iostream>
using namespace std;
#include<queue>
struct Node
{
    int x;
    int y;
    int t;
};
Node N,P;
int dir[][2]={{1,0},{0,1},{-1,0},{0,-1}};		//����
bool mark[25][25];
int n,m,s_x,s_y;
char map[25][25];
int main()
{
    void bfs();
    while(scanf("%d%d",&n,&m)!=EOF)
    {
		memset(map,0,sizeof(map));
        int i,j;
        getchar();
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)
            {
                scanf("%c",&map[i][j]);
                if(map[i][j]=='S')
                {
                    s_x=i;s_y=j;//��¼��ʼ����
                }
            }
            getchar();
        }
        bfs();
        cout<<N.t<<endl;
    }
}
void bfs()
{
    memset(mark,0,sizeof(mark));
    queue<Node>Q;
    N.t=0;N.x=s_x;N.y=s_y;
    Q.push(N);
    mark[N.x][N.y]=1;
    while(!Q.empty())
    {
        N=Q.front();
        Q.pop();
        if(map[N.x][N.y]=='T')
        {
            break;
        }
        int i;
        for( i=0;i<4;i++)
        {
            int tx=N.x+dir[i][0];
            int ty=N.y+dir[i][1];
            if(tx>=0 && tx<n && ty>=0 && ty<m && map[tx][ty]!='*' && !mark[tx][ty])
            {
            
                if(map[tx][ty]=='.'||map[tx][ty]=='T')
                {
                    P.t=N.t+1;
                    P.x=tx;
                    P.y=ty;
                    Q.push(P);    
                    mark[tx][ty]=1;
                }
                int Tx,Ty;
                if(map[tx][ty]=='|')
                {
                    
                  if(N.t%2==0 && N.y==ty)
                  {
                      if(N.x>tx)
                      {
                          Tx=tx-1;
                      }
                      else Tx=tx+1;
                      Ty=ty;
                      if(Tx>=0 && Tx<n && map[Tx][Ty]!='*' && !mark[Tx][Ty])
                      {
                              P.t=N.t+1;
                              P.x=Tx;
                              P.y=Ty;
                              mark[tx][ty]=1;
                              mark[Tx][Ty]=1;
                              Q.push(P);
                      }
                      
                  }
                  if(N.t%2==0 && N.y!=ty)
                  {
                      P.t=N.t+1;
                      P.x=N.x;
                      P.y=N.y;
                      Q.push(P);
                  }
                  if(N.t%2!=0 && N.x == tx)
                  {
                      if(N.y>ty)
                          Ty=ty-1;
                      else 
                          Ty=ty+1;
                      Tx=tx;
                      if(Ty>=0 && Ty<m && map[Tx][Ty]!='*' && !mark[Tx][Ty])
                      { 
                            P.t=N.t+1;
                            P.x=Tx;
                            P.y=Ty;
                            mark[tx][ty]=1;
                            mark[Tx][Ty]=1;
                            Q.push(P);
                      }
                        
                  }
                  if(N.t%2!=0 && N.x != tx)
                  {
                      P.t=N.t+1;
                      P.x=N.x;
                      P.y=N.y;
                      Q.push(P);
                  }
                }
                else if(map[tx][ty]=='-')
                {
                    if(N.t%2==0 && N.x==tx)
                    {
                        if(N.y>ty)
                            Ty=ty-1;
                        else 
                          Ty=ty+1;
                      Tx=tx;
                      if(Ty>=0 && Ty<m && map[Tx][Ty]!='*' && !mark[Tx][Ty])
                      { 
                            P.t=N.t+1;
                            P.x=Tx;
                            P.y=Ty;
                            mark[tx][ty]=1;
                            mark[Tx][Ty]=1;
                            Q.push(P);
                      }
                    }
                    if(N.t%2==0 && N.x!=tx)
                    {
                      P.t=N.t+1;
                      P.x=N.x;
                      P.y=N.y;
                      Q.push(P);
                    }
                    if(N.t%2!=0 && N.y==ty)
                    {
                        if(N.x>tx)
                            Tx=tx-1;
                        else Tx=tx+1;
                        Ty=ty;
                        if(Tx>=0 && Tx<n && map[Tx][Ty]!='*' && !mark[Tx][Ty])
                        {
                              P.t=N.t+1;
                              P.x=Tx;
                              P.y=Ty;
                              mark[tx][ty]=1;
                              mark[Tx][Ty]=1;
                              Q.push(P);
                      }
                    }
                    if(N.t%2!=0 && N.y!=ty)
                    {
                      P.t=N.t+1;
                      P.x=N.x;
                      P.y=N.y;
                      Q.push(P);
                    }
                }
            }
        }
    }
}


