#include<stdio.h>
#include <string>
using namespace std;
int main()
{
	int n,i,len,j,cl,k;
	char ch[205],t[20][205];
	while(scanf("%d",&n)&&n)
	{
		scanf("%s",ch);
		memset(t,'x',sizeof(char));
		len=strlen(ch);
		if(len%n==0) cl=len/n;
		else	cl=len/n+1;
		for(k=0;k<len;k++)
		{
			if((k/n)%2==0)	//ż����
			{
				t[k/n][k%n]=ch[k];
			}
			else if((k/n)%2==1)	//������
			{
				t[k/n][n-k%n-1]=ch[k];
			}
		}
		for(j=0;j<n;j++)
		{
			for(i=0;i<cl;i++)
			{
				printf("%c",t[i][j]);//�����t[i][j]д��t[j][i]����2Сʱ!!!
			}
		}
		printf("\n");
	}
}