//3.13  1H Accepted 1181 0MS 248K 784 B 
/*��һ��WA���˿���ֻ��һ����ĸ�����*/
#include<iostream>
#include<string>
using namespace std;
int map[26][26],n,v[26];
void dfs(int i)
{
	int j;
	v[i]=1;
	for(j=0;j<26;j++)
		if(v[j]==0 && map[i][j]!=0 )
			dfs(j);
}
int main()
{
	int i,j,k,fir,las;
	char ch[1000];
	while(scanf("%s",ch) !=EOF)
	{
		memset(map,0,sizeof(map));
		memset(v,0,sizeof(v));
		if(strlen(ch)==1)
		{//ע��ֻ��һ����ĸ�����
			for(i=0;i<26;i++)
				map[ch[0]-'a'][i]=map[i][ch[0]-'a']=1;
		}
		else
			map[ch[0]-'a'][ch[strlen(ch)-1] - 'a'] = 1;
		while(scanf("%s",ch) && strcmp(ch,"0"))
		{
			if(strlen(ch)==1)
			{
				for(i=0;i<26;i++)
					map[ch[0]-'a'][i]=map[i][ch[0]-'a']=1;
			}
			else
				map[ch[0]-'a'][ch[strlen(ch)-1] - 'a'] = 1;
		}
		dfs(1);
		if(v[12]==1)
			printf("Yes.\n");
		else printf("No.\n");
	}
}

