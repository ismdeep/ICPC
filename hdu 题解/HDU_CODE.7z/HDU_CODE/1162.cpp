//3.12 15min һ��Accepted 1162 0MS 756K 
#include<iostream>
#include<math.h>
#define INTMAX 1000000000;
using namespace std;
double map[1000][1000];
int n;
typedef struct{double x,y;}st;
double prim(int n)
{
	double min[1000],ret=0;
	int  v[1000],i,j,k;
	for(i=0;i<n;i++)
	{
		min[i] = INTMAX;
		v[i] =0;
	}
	for(min[j=0]=0;j<n;j++)
	{
		for(k=-1,i=0;i<n;i++)
			if(!v[i]&& (k==-1||min[i]<min[k]))
				k=i;
			for(v[k]=1,ret += min[k],i=0;i<n;i++)
				if(!v[i]&&map[k][i] <min[i])
					min[i] = map[k][i];
	}return ret;
}

st t[1000];
int main()
{
	int m,i,j,k,index;
	double x,y;
	while(scanf("%d",&n) != EOF)
	{
		for(i=0;i<n;i++)
			scanf("%lf%lf",&t[i].x,&t[i].y);
		for(i=0;i<n;i++)
			for(j=i;j<n;j++)//Ϊ�˽�ʡʱ��j���Դ�i��ʼ����
					map[i][j] = map[j][i] = hypot((t[i].x-t[j].x),(t[i].y-t[j].y));
			printf("%.2lf\n",prim(n));
	}
	
}
