/*��һ���������ӣ��ٶȼ��ٵ����� WA
Sample Input ����Ŵ�1��ʼ		Sample Output
6008 1300	�������� �ܵ��ٶ�	4
6000 2100						4
500 2000						5
1000 4000						9
1100 3000						7
6000 2000						
8000 1400
6000 1200
2000 1900		*/
#include <iostream>
#include <algorithm>
using namespace std;
typedef struct {int w;int s;int i;}st;
st m[1001],temp;
int a[1001],h[1001];
bool cmp(st a,st b)
{//��������ͬ���ٶȽ���
	if(a.w != b.w)
		return a.w<b.w;
	return a.s>b.s;
}
void output(int ma,int s)
{
    if(ma<0)
        return;
    a[ma-1]=m[s].i;
    output(ma-1,h[s]);
}
int main(int argc, char *argv[])
{
	freopen("C:\\Documents and Settings\\Administrator\\����\\test.txt","r",stdin);

    int f[1001],i,j,mi,mj,n=0,si,sj;
    while(scanf("%d%d",&m[n].w,&m[n].s) != EOF)
    {
        m[n].i=n+1;
        n++;
    }//nΪ�ܹ���������Ŀ
	sort(m,m+n,cmp);
    for(i=0;i<n;i++)
    {
        h[i]=i;
        f[i]=1;
    }
    mi=-1;//��ʼdp
    for(i=1;i<n;i++)
    {
        mj=-1;
        for(j=0;j<i;j++)
        {
            if(f[j]>mj && m[j].w<m[i].w && m[j].s>m[i].s)
            {
                mj=f[j];
                sj=j;
            }
        }
        if(mj!=-1)
        {
            f[i]=mj+1;
            h[i]=sj;
        }
        if(f[i]>mi)
        {
            mi=f[i];
            si=i;
        }
    }
    output(mi,si);
    cout<<mi<<endl;
    for(i=0;i<mi;i++)
        cout<<a[i]<<endl;
}

