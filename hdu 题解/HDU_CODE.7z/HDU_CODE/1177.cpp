//����3.14 30min Accepted 1177 0MS 268K 
#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
typedef struct{int ac,index;char time[10];}Node;
Node t[200];
bool cmp(Node a,Node b)
{
	if(a.ac != b.ac)
		return a.ac > b.ac;
	return strcmp(b.time,a.time);
}
int main()
{
	int n,m,i,j,g,s,c;
	while(scanf("%d%d%d%d%d",&n,&g,&s,&c,&m)&&n&&g&&s&&c&&m)
	{
		for(i=0;i<n;i++)
		{
			scanf("%d %s",&t[i].ac,t[i].time);
			t[i].index=1+i;
		}
		sort(t,t+n,cmp);
		for(i=0;i<n;i++)
		{
			if(t[i].index==m)
			{
				if(g>0)
					printf("Accepted today? I've got a golden medal :)\n");
				else if(s>0)
					printf("Accepted today? I've got a silver medal :)\n");
				else if(c>0)
					printf("Accepted today? I've got a copper medal :)\n");
				else
					printf("Accepted today? I've got an honor mentioned :)\n");
			}
			if(g>0) g--;
			else if(s>0) s--;
			else if(c>0) c--;
		}
	}
}

