//�Լ����������������
#include <iostream>
#include <stdlib.h>
using namespace std;
int main(int argc, char *argv[])
{
  int c1[250001],c2[250001];
  int data1[51],data2[51],i;
  int n,m,s;
  while(cin>>n)
  {
      m=0,s=0;
      if (n<0) break;
      if (n==0) cout<<0<<" "<<0<<endl;
        for(int i=1;i<=n;i++)
        {
          cin>>data1;cin>>data2;
          m=m+data1*data2;  
        }
                      
        for(int i=0;i<=m;i++)
        {
            c1=0;c2=0;
        }
        for(int i=0;i<=data1[1]*data2[1];i=i+data1[1])
        c1=1;
      
            
        s=data1[1]*data2[1];
        for(int k=1;k<n;k++)
            {
              // s=s+data1[k]*data2[k];
            for(int i=0;i<=s;i=i+1) //�ĳ������Ŷ԰�
            for(int j=0;j<=data1[k+1]*data2[k+1];j=j+data1[k+1])
                      {
                    c2[i+j]=c2[i+j]+c1; 
                    }
            s=s+data1[k+1]*data2[k+1];                                              
            for(int i=0;i<=s;i++)
            {
                c1=c2;c2=0;
                }
                                                                              
        }                                                                                                      
                                                                                                                                
        //for(int k=0;k<=s;k++)
        //cout<<c1[k]<<endl;
          //cout<<c1[m/2]<<endl;
        int p;
          for (p=m/2;p>=0;p--)
          {
              if (c1[p]!=0)            //��ͬ�ĵط�������!!!
                  {break;} 
          }
          cout<<m-p<<" "<<p<<endl;
                                                                                                                                                                    
              
}    
  
//system("PAUSE");    
  return 0;
}