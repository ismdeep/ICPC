//��·����̵Ĳ�ͬ��·��
#include<iostream>
using namespace std;

int a[1001][1001],b[1001],c[1001],e[1001],n,m;
void minway()
{
    int i,j,k,l,min;
    k=n;
    l=2;
    b[2]=0;
    while(k--)
    {
        min=-1;
        for(i=1;i<=n;i++)
            if(a[i][l] && (b[i]==-1 || b[i]>b[l]+a[i][l]))
                b[i]=b[l]+a[i][l];
        c[l]=0;
        for(i=1;i<=n;i++)
            if(c[i] && b[i]>-1)
                if(min==-1)
                {
                    min=b[i];
                    l=i;
                }
                else if(min>b[i])
                {
                    min=b[i];//��ŵ�ǰ���·��
                    l=i;
                }
    }
}
int getnum(int l)
{
    int i,j,num=0;
    if(l==2)
        return 1;
    for(i=1;i<=n;i++)
        if(a[i][l] && b[l]>b[i])
        {
            if(e[i]==0)
                e[i]=getnum(i);
            num+=e[i];
        }
    return num;
}
void main()
{
    int i,j,d,k;
    while(scanf("%d %d",&n,&m),n>0)
    {
        for(i=1;i<=n;i++)
        {//��ʼ��
            for(j=1;j<=n;j++)
                a[i][j]=0;
            b[i]=-1;
            c[i]=1;
            e[i]=0;
        }
        for(k=0;k<m;k++)
        {
            scanf("%d %d %d",&i,&j,&d);
            a[j][i]=a[j][i]=d;
        }
        minway();
        printf("%d\n",getnum(1));
    }
}