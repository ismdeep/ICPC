#include <iostream>
using namespace std;

#ifndef DEFAULT_STACK_SIZE
#define DEFAULT_STACK_SIZE 1000
#endif

// end 
// iCoding@CodeLab
//

