#include "Stack.cpp"
#include "Head.h"

int main ()
{
	cout << "Hello World!" << endl;
}

// end 
// iCoding@CodeLab
//


